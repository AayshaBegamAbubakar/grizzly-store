create database vendor;

use vendor;

CREATE TABLE `vendor` (
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `vendor`.`vendor`
(`username`,
`password`,
`role`,
`status`)
VALUES
(muffin,muffin20,admin,active);


INSERT INTO `vendor`.`vendor`
(`username`,
`password`,
`role`,
`status`)
VALUES
(mugas,mugas,vendor,active);

CREATE TABLE `product` (
  `ProductID` int(11) NOT NULL,
  `ProductList` varchar(50) DEFAULT NULL,
  `ProductBrand` varchar(50) DEFAULT NULL,
  `ProductCategory` varchar(50) DEFAULT NULL,
  `ProductOffer` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ProductID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `vendor`.`product`
(`ProductID`,
`ProductList`,
`ProductBrand`,
`ProductCategory`,
`ProductOffer`)
VALUES
(<{ProductID: }>,
<{ProductList: }>,
<{ProductBrand: }>,
<{ProductCategory: }>,
<{ProductOffer: }>);


CREATE TABLE `invent` (
  `ProductID` int(11) DEFAULT NULL,
  `Stack` int(11) DEFAULT NULL,
  `Buffer` int(11) DEFAULT NULL,
  KEY `ProductID` (`ProductID`),
  CONSTRAINT `invent_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `product` (`ProductID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `vendor`.`invent`
(`ProductID`,
`Stack`,
`Buffer`)
VALUES
(<{ProductID: }>,
<{Stack: }>,
<{Buffer: }>);



