LOGIN :
   1.Develop login authentication feature using Servlet, JDBC, JSP and Servlet Filter.

LOGIN ROLE CHECK : 
   2.After Login ,check Role of Login User .
   3.If Login User is Admin,It give Admin Web Page.
   4.Else It will Display Vendor Web Page.
   
 LOGIN  ACCOUNT LOCK :
 	1.On 3 consecutive invalid attempts, the Login access to be locked 
 	2.After Ward we Cant Access the Account Until certeain periods.
 	
 ADMIN LOGIN ACCOUNT :
 
 	1.On successful login, Show home page for Admin.
 	
 	ADD PRODUCT:
 	2.Develop "Add Product" feature by Admin user, using JDBC, Servlet, JSP and JSTL.
 	
 	LIST PRODUCT :
 	3.Develop "List Product" feature by Admin user, using JDBC, Servlet, JSP and JSTL.
 	
 	VIEW PRODUCT :
 	4.Develop "View Product" feature by Admin user, using JDBC, Servlet, JSP and JSTL.
 	5.Use PRODUCT table already created in database.
 	6.Show all the product info.
 	
 VENDOR LOGIN ACCOUNT :
 	1.Develop Vendor authentication feature using Servlet, JDBC, JSP and Servlet Filter.
 	2.On successful login, Show home page.
 	
 	ADD PRODUCT:
 	3.Develop "Add Product" feature by Vendor user, using JDBC, Servlet, JSP and JSTL.
 	
 	LIST PRODUCT :
 	4.list products from the table.
 	
 	MANAGE PRODUCT QUANTITY :
 	5.vendor, select the product and provide the quantity.
 	6.Create join table between product and vendor with quantity field.
 	
 	INVENTORY PRODUCT :
 	7.Develop "Inventory" feature for Vendor user, using JDBC, Servlet, JSP and JSTL.
 	8.List products with quantity for logged in vendor
 
 LOGOUT :
 	1.On logout, terminate session and show login page	