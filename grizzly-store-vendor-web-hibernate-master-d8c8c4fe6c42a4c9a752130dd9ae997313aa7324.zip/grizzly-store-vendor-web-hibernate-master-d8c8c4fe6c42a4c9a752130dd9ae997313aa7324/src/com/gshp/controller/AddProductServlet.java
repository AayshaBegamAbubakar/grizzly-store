package com.gshp.controller;


import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.gshp.dao.ApplicationException;
import com.gshp.dao.HibernateDao;
import com.gshp.dao.HibernateDaoImplements;
import com.gshp.pojo.Productpojo;
import com.gshp.service.HibernateService;
import com.gshp.service.HibernateServiceImplements;

/**
 * Servlet implementation class AddProductServlet
 */
@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    public static Logger logger = Logger.getLogger("grizzly-store");
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String productID=request.getParameter("ProductID");
		String productName=request.getParameter("ProductList");
		String productBrand=request.getParameter("ProductBrand");
		String productCategory=request.getParameter("ProductCategory");
		String productOffer=request.getParameter("ProductOffer");
		
		Productpojo pojo= new Productpojo();
		int id=Integer.parseInt(productID);
		
		pojo.setProductID(id);
		pojo.setProductList(productName);
		pojo.setProductBrand(productBrand);
		pojo.setProductCategory(productCategory);
		pojo.setProductOffer(productOffer);
		
		
		HibernateService product= new  HibernateServiceImplements();
		try {
			product.insertProduct(pojo);
ArrayList allProducts=product.fetchProduct();
			
			request.setAttribute("arrayList", allProducts);
			
			
			RequestDispatcher rd=request.getRequestDispatcher("Fetch.jsp");
			rd.forward(request, response);
		} catch (ApplicationException e) {
			logger.error(e);
		}
		  
		
      
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
			doGet(request, response);
		
	}

}
