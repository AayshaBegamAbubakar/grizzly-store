package com.gshp.controller;


import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.omg.CORBA.portable.ApplicationException;

import com.gshp.dao.HibernateDao;
import com.gshp.service.HibernateService;
import com.gshp.service.HibernateServiceImplements;

/**
 * Servlet implementation class FetchProductServlet
 */
@WebServlet("/FetchProductServlet")
public class FetchProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FetchProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    public static Logger logger = Logger.getLogger("grizzly-store");
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 ArrayList allProduct;
		HibernateService product= new  HibernateServiceImplements();
		
		try {
			allProduct = product.fetchProduct();
			request.setAttribute("arrayList", allProduct);
			 RequestDispatcher dispatcher= request.getRequestDispatcher("Fetch.jsp");
			 dispatcher.forward(request, response);
		} catch (com.gshp.dao.ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
