package com.gshp.controller;



import java.io.IOException;


import com.gshp.dao.HibernateDao;
import com.gshp.dao.LoginDao;
import com.gshp.dao.LoginDaoImplements;
import com.gshp.pojo.LoginPojo;
import com.gshp.service.HibernateService;
import com.gshp.service.HibernateServiceImplements;
import com.gshp.service.LoginService;
import com.gshp.service.LoginServiceImplements;


import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.omg.CORBA.portable.ApplicationException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class GrizzlyServlet
 */
@WebServlet("/GrizzlyServlet")
public class GrizzlyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GrizzlyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    ArrayList arrayList=null;
    int id;
    public static Logger logger = Logger.getLogger("grizzly-store");
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		if(request.getParameter("Logout") != null)
		{
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("LogoutServlet");
			dispatcher.forward(request, response);
					
		}

		if(request.getParameter("Add") != null)
		{
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("AddProductServlet");
			dispatcher.forward(request, response);
					
		}
		if(request.getParameter("Product") != null)
		{
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("FetchProductServlet");
			dispatcher.forward(request, response);
					
		}
		
		if(request.getParameter("Inventory") != null)
		{
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("InventoryServlet");
			dispatcher.forward(request, response);
					
		}
		if(request.getParameter("ProductID") != null)
		{
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("DeleteServlet");
			dispatcher.forward(request, response);
		}	
			if(request.getParameter("Manage") != null)
			{
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("ManageServlet");
				dispatcher.forward(request, response);
						
			}
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		String username = request.getParameter("username");
	    String password = request.getParameter("password");
	    
	    LoginPojo pojo = new LoginPojo();
		
		pojo.setUsername(username);
		pojo.setPassword(password);
		
		System.out.println(pojo.getUsername());
		
		LoginService login = new LoginServiceImplements();
		
		
			try {
				pojo =login.checkUser(pojo);
			} catch (com.gshp.dao.ApplicationException e1) {
				logger.error(e1);
			}
		
		
	    if(pojo.getStatus()==null)
        {
             RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
             request.setAttribute("error", "Invalid User and Password! Please try again!");
             rd.forward(request, response); 
        }
        else if(pojo.getStatus().equals("active"))
        { 
        	if(password.equals(pojo.getPassword()))
             {
                 
        	            HttpSession session=request.getSession();
                        session.setAttribute("username", username);
                        
                        session.removeAttribute("status");
                        session=request.getSession();
                        String user=(String) session.getAttribute("username");
                        
                        if(pojo.getRole().equals("vendor") ) 
                        {
                        	HibernateService product5= new HibernateServiceImplements();
                             ArrayList allProduct;
							try {
								allProduct = product5.inventoryProduct();
								session=request.getSession();
	                             request.setAttribute("arrayList", allProduct);
	                             RequestDispatcher requestDispatcher=request.getRequestDispatcher("VendorIframe.jsp");
	                             requestDispatcher.forward(request, response);
							} catch (Exception e) {
								logger.error(e);
							}
                             
                        }
                        else
                        {

                        	HibernateService product6= new HibernateServiceImplements();
                        	ArrayList allProducts;
							try {
								allProducts = product6.inventoryProduct();
								request.setAttribute("arrayList", allProducts);
	                            RequestDispatcher requestDispatcher=request.getRequestDispatcher("AdminIframe.jsp");
	                             requestDispatcher.forward(request, response);
							} catch (Exception e) {
								logger.error(e);
							}
                        }
               }
               else
               {
                         HttpSession session=request.getSession();
                         String user=(String) session.getAttribute("user");
                         if(request.getParameter("username").equals(user))
                         {
                                int status=(Integer)session.getAttribute("status");
                                if(status==0)
                                { 
                                	session.setAttribute("username", username);
                                    session.setAttribute("status", 1);
                                    RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                                    request.setAttribute("error", "Invalid Password! Please try again 0!");
                                    rd.forward(request, response); 
                                }
                               
                                 else if(status==2)
                                 {
                                      session.invalidate();
                                      	try {
											login.loginLock(pojo);
										} catch (com.gshp.dao.ApplicationException e) {
											logger.error(e);
										}
									
                                      RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                                      request.setAttribute("error", "You have attempted thrice with wrong password!!. Account is locked!!");
                                      rd.forward(request, response); 
                                  }
                                  else
                                  {
                                       session.setAttribute("status", ++status);
                                       RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                                       request.setAttribute("error", "Invalid Password! Please try again 2!");
                                       rd.forward(request, response); 
                                  }
                        }
                        
                  
                         else
                         {
                        session.setAttribute("user", username);
                        session.setAttribute("status", 1);
                        RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                        request.setAttribute("error", "Invalid Password! Please try again first!");
                        rd.forward(request, response); 
                         }
                 
                }
           }
           else
           {
                 RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
                 request.setAttribute("error", "Account is locked!!");
                 rd.forward(request, response); 
            }
           
    }

}


