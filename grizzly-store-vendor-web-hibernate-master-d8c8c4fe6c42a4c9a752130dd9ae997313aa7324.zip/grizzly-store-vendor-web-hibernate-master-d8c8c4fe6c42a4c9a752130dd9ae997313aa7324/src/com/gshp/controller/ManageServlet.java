package com.gshp.controller;


import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;


import com.gshp.dao.HibernateDao;
import com.gshp.pojo.Productpojo;
import com.gshp.service.HibernateService;
import com.gshp.service.HibernateServiceImplements;

/**
 * Servlet implementation class ManageServlet
 */
@WebServlet("/ManageServlet")
public class ManageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ManageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
ArrayList arrayList2=null;
public static Logger logger = Logger.getLogger("grizzly-store");
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


	    
	    int  Stack =Integer.parseInt(request.getParameter("Stack"));
      int  Buffer = Integer.parseInt(request.getParameter("Buffer"));
        int ProductId=Integer.parseInt(request.getParameter("user"));
        Productpojo Pojo=new Productpojo();
      
        Pojo.setStack(Stack);
        Pojo.setBuffer(Buffer);
     Pojo.setProductID(ProductId);
		
		
		HibernateService product= new  HibernateServiceImplements();
		
		int flag;
		try {
			flag = product.updateInventoryProduct(Pojo);
			if(flag==1) {
				arrayList2 = product.inventoryProduct();
				request.setAttribute("arrayList",arrayList2);
				RequestDispatcher  rd=request.getRequestDispatcher("InventoryFetch.jsp") ;
				rd.forward(request, response);
		 }
		} catch (com.gshp.dao.ApplicationException e) {
			logger.error(e);
		}
 
			
			
	}
			
		
	        
	    
	


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
