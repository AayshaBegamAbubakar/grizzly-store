package com.gshp.dao;



import java.util.ArrayList;

import com.gshp.pojo.Productpojo;


public interface HibernateDao {
	ArrayList fetchProduct() throws ApplicationException;
	 ArrayList inventoryProduct() throws ApplicationException ;
	 int updateInventoryProduct(Productpojo pojo) throws ApplicationException;
	 void insertProduct(Productpojo pojo) throws ApplicationException ;
	 int removeProduct(int id) throws ApplicationException;
}