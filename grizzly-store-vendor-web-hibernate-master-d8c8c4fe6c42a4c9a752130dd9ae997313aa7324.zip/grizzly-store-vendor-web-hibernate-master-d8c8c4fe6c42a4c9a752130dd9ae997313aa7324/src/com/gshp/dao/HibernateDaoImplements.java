package com.gshp.dao;

import java.util.ArrayList;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.gshp.HibernateUtil.HibernateUtil;
import com.gshp.pojo.Productpojo;

public class HibernateDaoImplements implements HibernateDao {


public  ArrayList fetchProduct() throws ApplicationException
{
	SessionFactory sf= null;
	  Session session = null;
	  ArrayList allProducts=new ArrayList();
	

	  Product product;
	  try
	  {
		  sf=HibernateUtil.getSessionFactory();
		  session=sf.openSession();
		  List list=session.createQuery("from Product").list();
		  for(int i=0;i<list.size();i++)
    	  {
    		   product= (Product)list.get(i);
    		   Productpojo Pojo= new Productpojo();
    		   
    		  Pojo.setProductID(product.getProductID());
    		  System.out.println(product.getProductID());
    		  
    		  Pojo.setProductList(product.getProductList());
    		  System.out.println(product.getProductList());
    		  
    		  Pojo.setProductBrand(product.getProductBrand());
    		  System.out.println(product.getProductBrand());
    		  
    		  Pojo.setProductCategory(product.getProductCategory());
    		  System.out.println(product.getProductCategory());
    		  
    		  Pojo.setProductOffer(product.getProductOffer());
    		  System.out.println(product.getProductOffer());
    		  allProducts.add(Pojo);
    		  
    	  }
	  }
	  catch(HibernateException e)
	  {
		 String error = e.getMessage();
          throw new ApplicationException(error);
	  }
	  finally
	  {
		  session.close();
	  }
	 
	  return allProducts; 	     
	 
}
public  ArrayList inventoryProduct() throws ApplicationException 
{
	SessionFactory sf= null;
	  Session session = null;
	  ArrayList arrayList=new ArrayList();
	 

	  
	  int required=0;
	  try
	  {
	      sf=HibernateUtil.getSessionFactory();
	  session=sf.openSession();
		  List list=session.createQuery("from Product").list();
		  for(int i=0;i<list.size();i++)
    	  {
			  Productpojo Pojo= new Productpojo();
			  Product product= (Product)list.get(i);
    		  Pojo.setProductID(product.getProductID());
    		  System.out.println(product.getProductID());
    		  
    		  Pojo.setProductList(product.getProductList());
    		  System.out.println(product.getProductList());

    		  Pojo.setProductBrand(product.getProductBrand());
    		  System.out.println(product.getProductBrand());
    		  
    		  Pojo.setProductCategory(product.getProductCategory());
    		  
    		  Pojo.setProductOffer(product.getProductOffer());

    		  Pojo.setBuffer(product.getInventory().getBuffer());
    		  System.out.println(product.getInventory().getBuffer());
    		  
    		  Pojo.setStack(product.getInventory().getStack());
    		  System.out.println(product.getInventory().getStack());
    		  
    		  required=(product.getInventory().getStack())-(product.getInventory().getBuffer());
				
				if(required<0)
				{
					required=-(required);
					Pojo.setRequired(required);
				}
				else
				{
					Pojo.setRequired(0);
				}
    		  arrayList.add(Pojo);
    		  
    		              
    	  	   
    	  }
	  }
	  catch(HibernateException e)
	  {
		 String error = e.getMessage();
          throw new ApplicationException(error); 
	  }
	  finally
	  {
		  session.close();
	  }
	  
	  return arrayList; 	     
	 
}

public  int updateInventoryProduct(Productpojo pojo) throws ApplicationException {
       
              SessionFactory sessionFactory =null;
               Session session =null;
               Transaction transaction =null;
              Productpojo gPojo=new Productpojo();
              try {
                    sessionFactory = HibernateUtil.getSessionFactory();
               session = sessionFactory.openSession();
               transaction = session.beginTransaction();
                     Product product = session.get(Product.class, pojo.getProductID());
            
                     product.getInventory().setBuffer(pojo.getBuffer());
                     product.getInventory().setStack(pojo.getStack());
                     session.update(product);
                     transaction.commit();
                     } 
                catch (HibernateException e) {
                     try {
                           transaction.rollback();
                          
                     } catch (RuntimeException runtimeEx) {
                           System.err.printf("Couldnt Roll Back Transaction", runtimeEx);
                     }
                    String error = e.getMessage();
                    throw new ApplicationException(error);
              } 
              finally {
                     if (session != null) {
                           session.close();
                     }
              }

              return 1;

       }
public  void insertProduct(Productpojo pojo) throws ApplicationException { 
    Session session = null;
    try {
           session = HibernateUtil.getSessionFactory().openSession();
           Product product = new Product();
           product.setProductID(pojo.getProductID());
           product.setProductList(pojo.getProductList());
           product.setProductCategory(pojo.getProductCategory());
           product.setProductBrand(pojo.getProductBrand());
           product.setProductOffer(pojo.getProductOffer());

           session.beginTransaction();
           session.save(product);

           session.getTransaction().commit();
           
           Inventory in = new Inventory();
           in.setProductID(pojo.getProductID());
           in.setStack(0);
           in.setBuffer(0);
           
           session.beginTransaction();
           session.save(in);

           session.getTransaction().commit();

    }
catch (HibernateException e) {

	
    throw new ApplicationException(e.getMessage());
}
 finally {
                     if (session != null) {
                           session.close();
                     }
              }

}


public   int removeProduct(int id) throws ApplicationException {
    Session session = null;
    
           
            try {
                session = HibernateUtil.getSessionFactory().openSession();
                session.beginTransaction();
                

                Product product = (Product) session.get(Product.class, id);

                session.delete(product);

                session.getTransaction().commit();
            }
            catch (HibernateException e) {
            	 String error = e.getMessage();
                 throw new ApplicationException(error);
            }
             finally {
                     if (session != null) {
                           session.close();
                     }
              }
return 0;
        }


}
