package com.gshp.dao;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="invent")
public class Inventory {
	


	@Id
	@Column(name="ProductID")
	private int ProductID;
	
	@Column(name="Buffer")
	private int Buffer;

	@Column(name="Stack")
	private int Stack;
	
	

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="ProductID")
	private Product product;
		
	
	public Inventory()
	{
		
	}
	public Inventory(int productID, int buffer, int stack) {
		super();
		ProductID = productID;
		Buffer = buffer;
		Stack = stack;
		
	}


	public int getProductID() {
		return ProductID;
	}


	public void setProductID(int productID) {
		ProductID = productID;
	}


	public int getBuffer() {
		return Buffer;
	}


	public void setBuffer(int buffer) {
		Buffer = buffer;
	}


	public int getStack() {
		return Stack;
	}


	public void setStack(int stack) {
		Stack = stack;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}
	

	
	
}
