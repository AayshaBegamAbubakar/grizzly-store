package com.gshp.dao;

import com.gshp.pojo.LoginPojo;
public interface LoginDao {

   boolean roleCheck(LoginPojo lPojo)throws ApplicationException;
	
   LoginPojo checkUser(LoginPojo pojo)throws ApplicationException;
   
   public  void  loginLock(LoginPojo lPojo)throws ApplicationException;

}
