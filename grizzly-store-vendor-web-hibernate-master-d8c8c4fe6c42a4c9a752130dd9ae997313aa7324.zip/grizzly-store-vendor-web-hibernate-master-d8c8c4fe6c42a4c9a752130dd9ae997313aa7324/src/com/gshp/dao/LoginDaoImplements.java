package com.gshp.dao;

import org.hibernate.HibernateException;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.gshp.HibernateUtil.HibernateUtil;
import com.gshp.pojo.LoginPojo;

public class LoginDaoImplements implements LoginDao{
	public  boolean roleCheck(LoginPojo lPojo) throws ApplicationException
	{
	       SessionFactory sf= null;
	         Session session =null;
	         boolean flag=false;
	         try {
	         sf=HibernateUtil.getSessionFactory();
	         session=sf.openSession();
	         Login login = session.load(Login.class,lPojo.getUsername());
	       
	     
	         if(login.getUsername()!=null && login.getUsername()!="")
	         {
	                lPojo.setUsername(login.getUsername());
	                lPojo.setPassword(login.getPassword());
	                lPojo.setRole(login.getRole());
	                lPojo.setStatus(login.getStatus());
	         }
	         
	         
	         if(lPojo.getRole()==null)
	                flag= false;
	         
	         else flag=true;
	         }
	         catch(HibernateException e)
	         {
	        	 
	         String error = e.getMessage();
	           throw new ApplicationException(error);
	         }
	         finally
          {
           session.close();
          }
			return flag;
	        
	}
	public  LoginPojo checkUser(LoginPojo pojo) throws ApplicationException  {
	    SessionFactory sf= null;
	         Session session =null;
	         try
	         {
	        	 sf=HibernateUtil.getSessionFactory();
	             session=sf.openSession();
	             
	              Login login =session.get(Login.class,pojo.getUsername());
	           
	                       if(login.getUsername()!=null && login.getUsername()!="")
	                       {
	                             pojo.setUsername(login.getUsername());
	                             pojo.setPassword(login.getPassword());
	                             pojo.setRole(login.getRole());
	                             pojo.setStatus(login.getStatus());
	                       }
	         }
	         catch(HibernateException e)
	         {
	        	 String error = e.getMessage();
		           throw new ApplicationException(error);
	            
	         }
	        finally
          {
           session.close();
          }
	         return pojo;
	         }
    public  void  loginLock(LoginPojo lPojo) throws ApplicationException 
    {
                   

          SessionFactory sf= null;
             Session session = null;
             String count="inactive";
                  
          try
          {
        	  sf=HibernateUtil.getSessionFactory();
              session = sf.openSession();
              
              System.out.println(lPojo.getUsername());
              System.out.println(lPojo.getPassword());
              System.out.println(lPojo.getStatus());
              System.out.println(lPojo.getRole());
              
              Transaction transaction=session.beginTransaction(); 
              Login i= new Login(lPojo.getUsername(),lPojo.getPassword(),lPojo.getRole(),count);
               
              
           session.update(i);
           session.getTransaction().commit();
          }
          catch(HibernateException e)
          {
        	  String error = e.getMessage();
	           throw new ApplicationException(error);
          }
          finally
          {
           session.close();
          }
             
	}

}
