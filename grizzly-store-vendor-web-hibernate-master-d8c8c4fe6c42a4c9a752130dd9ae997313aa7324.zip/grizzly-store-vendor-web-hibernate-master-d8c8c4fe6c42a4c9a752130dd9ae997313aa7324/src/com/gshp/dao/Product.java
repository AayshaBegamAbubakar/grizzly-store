package com.gshp.dao;


import javax.persistence.CascadeType;
import javax.persistence.Column;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="product")
public class Product {
	 
	@Id
	
      @Column(name="ProductID")
	  private int ProductID;
	 
      @Column(name="ProductList")
		private String ProductList;
	 
      @Column(name="ProductBrand")
	    private String ProductBrand;
	 
      @Column(name="ProductCategory")
	    private String ProductCategory;
	 
     
      @Column(name="ProductOffer")
	    private String ProductOffer;
      
      @OneToOne(mappedBy="product",cascade=CascadeType.ALL)
  	
  	private Inventory inventory;

  	
   
      public Product()
      {
    	  
      }
      
      
    	public int getProductID() {
		return ProductID;
	}

	public void setProductID(int productID) {
		ProductID = productID;
	}

	public String getProductList() {
		return ProductList;
	}

	public void setProductList(String productList) {
		ProductList = productList;
	}


	public String getProductBrand() {
		return ProductBrand;
	}


	public void setProductBrand(String productBrand) {
		ProductBrand = productBrand;
	}


	public String getProductCategory() {
		return ProductCategory;
	}


	public void setProductCategory(String productCategory) {
		ProductCategory = productCategory;
	}


	public String getProductOffer() {
		return ProductOffer;
	}


	public void setProductOffer(String productOffer) {
		ProductOffer = productOffer;
	}

	public Inventory getInventory() {
		return inventory;
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	
	

	public Product(int productID, String productList, String productBrand, String productCategory, String productOffer
			) {
		super();
		ProductID = productID;
		ProductList = productList;
		ProductBrand = productBrand;
		ProductCategory = productCategory;
		ProductOffer = productOffer;
		
	}
	
	
}
