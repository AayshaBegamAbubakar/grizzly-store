package com.gshp.pojo;



public class Productpojo {
	
	private int ProductID;
	private String ProductList;
    private String ProductBrand;
    private String ProductCategory;
   
    private String ProductOffer;
    
    private int Stack;
    private int Buffer;
    private int Required;
    
    public int getProductID() {
		return ProductID;
	}
	public void setProductID(int productID) {
		ProductID = productID;
	}
	public String getProductList() {
		return ProductList;
	}
	public void setProductList(String productList) {
		ProductList = productList;
	}
	
	public int getStack() {
		return Stack;
	}
	public void setStack(int stack) {
		Stack = stack;
	}
	public int getBuffer() {
		return Buffer;
	}
	public void setBuffer(int buffer) {
		Buffer = buffer;
	}
	public int getRequired() {
		return Required;
	}
	public void setRequired(int required) {
		Required = required;
	}
	public String getProductBrand() {
		return ProductBrand;
	}
	public void setProductBrand(String productBrand) {
		ProductBrand = productBrand;
	}
	public String getProductCategory() {
		return ProductCategory;
	}
	public void setProductCategory(String productCategory) {
		ProductCategory = productCategory;
	}
	public String getProductOffer() {
		return ProductOffer;
	}
	public void setProductOffer(String productOffer) {
		ProductOffer = productOffer;
	}
	


}
