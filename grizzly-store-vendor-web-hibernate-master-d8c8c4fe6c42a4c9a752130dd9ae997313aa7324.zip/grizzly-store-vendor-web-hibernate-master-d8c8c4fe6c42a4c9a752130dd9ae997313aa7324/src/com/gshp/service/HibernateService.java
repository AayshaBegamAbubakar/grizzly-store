package com.gshp.service;

import java.util.ArrayList;

import com.gshp.dao.ApplicationException;
import com.gshp.pojo.Productpojo;

public interface HibernateService {
	ArrayList fetchProduct() throws ApplicationException;
	 ArrayList inventoryProduct() throws ApplicationException ;
	 int updateInventoryProduct(Productpojo pojo) throws ApplicationException;
	 void insertProduct(Productpojo pojo) throws ApplicationException ;
	 int removeProduct(int id) throws ApplicationException;
}
