package com.gshp.service;

import java.util.ArrayList;

import com.gshp.dao.ApplicationException;
import com.gshp.dao.HibernateDao;
import com.gshp.dao.HibernateDaoImplements;
import com.gshp.pojo.Productpojo;

public class HibernateServiceImplements implements HibernateService {
 HibernateDao product=new HibernateDaoImplements();
	@Override
	public ArrayList fetchProduct() throws ApplicationException {
		
		return product.fetchProduct();
	}

	@Override
	public ArrayList inventoryProduct() throws ApplicationException {
		
		return product.inventoryProduct();
	}

	@Override
	public int updateInventoryProduct(Productpojo pojo) throws ApplicationException {
		
		return product.updateInventoryProduct(pojo);
	}

	@Override
	public void insertProduct(Productpojo pojo) throws ApplicationException {
		product.insertProduct(pojo);
	}

	@Override
	public int removeProduct(int id) throws ApplicationException {
		
		return product.removeProduct(id);
	}

}
