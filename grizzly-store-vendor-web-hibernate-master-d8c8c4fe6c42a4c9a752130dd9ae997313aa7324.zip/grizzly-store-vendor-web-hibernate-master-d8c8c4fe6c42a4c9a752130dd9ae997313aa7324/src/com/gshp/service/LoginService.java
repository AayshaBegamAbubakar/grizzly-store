package com.gshp.service;

import com.gshp.dao.ApplicationException;
import com.gshp.pojo.LoginPojo;

public interface LoginService {

	   boolean roleCheck(LoginPojo lPojo) throws ApplicationException;
		
	   LoginPojo checkUser(LoginPojo pojo) throws ApplicationException;
	   
	   void loginLock(LoginPojo pojo) throws ApplicationException;


}
