package com.gshp.service;

import com.gshp.dao.ApplicationException;
import com.gshp.dao.LoginDao;
import com.gshp.dao.LoginDaoImplements;
import com.gshp.pojo.LoginPojo;

public class LoginServiceImplements implements LoginService {

	LoginDao login=new LoginDaoImplements();
	@Override
	public boolean roleCheck(LoginPojo lPojo) throws ApplicationException {
		boolean flag=login.roleCheck(lPojo);
		return flag;
	}

	@Override
	public LoginPojo checkUser(LoginPojo pojo) throws ApplicationException {
		
		return login.checkUser(pojo);
	}

	@Override
	public void loginLock(LoginPojo pojo) throws ApplicationException {
		login.loginLock(pojo);

	}

}
